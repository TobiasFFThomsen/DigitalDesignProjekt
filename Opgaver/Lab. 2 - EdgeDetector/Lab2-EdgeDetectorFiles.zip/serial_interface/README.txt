The serial_interface is a Python 3 (3.5) script.
It can run on WINDOWS, MAC, and Linux.
However you need to have a Python interpreter and the following packages installed (some are default packages):
- appJar
- sys
- glob
- serial
- re
- PIL (pillow)
- tkinter as tk
- time
- threading
